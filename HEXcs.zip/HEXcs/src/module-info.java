module HEXcs {
    requires java.sql;
    requires junit.platform.console.standalone;
    exports unit_testing;
}