package unit_testing;

import static org.junit.jupiter.api.Assertions.assertTrue;
import org.junit.jupiter.api.Test;
import dao.ProjectRepositoryImpl;
import Entity.model.*;

public class testing {
    ProjectRepositoryImpl projectRepository = new ProjectRepositoryImpl();
    
    @Test
    public void testCreateEmployee(){
		Employee employee = new Employee();
		employee.setId(21);
		employee.setName("test1");
		employee.setDesignation("designationm");
		employee.setGender("Male");
		employee.setSalary(45678);
		employee.setProject_id(2);
		
		boolean result = projectRepository.createEmployee(employee);
		assertTrue(result, "Employee creation Successful");
    }
    
    @Test
    public void testCreateTask(){

        Task task = new Task();
        task.setTask_id(10);
        task.setTask_name("Testing2");
        task.setProject_id(2);
        task.setEmployee_id(12);
        task.setStatus("Assigned");
        boolean result = projectRepository.createTask(task);
        assertTrue(result, "Task creation successful");
    } 
}
