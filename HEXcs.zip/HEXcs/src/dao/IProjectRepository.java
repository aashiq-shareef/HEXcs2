package dao;

import java.util.List;
import Entity.model.Employee;
import Entity.model.Project;
import Entity.model.Task;

public interface IProjectRepository {
    boolean createEmployee(Employee employee);
    boolean createProject(Project project);
    boolean createTask(Task task);
    boolean assignProjectToEmployee(int projectId, int employeeId);
    boolean assignTaskInProjectToEmployee(int taskId, int projectId, int employeeId);
    boolean deleteEmployee(int employeeId);
    boolean deleteProject(int projectId);
    List<Task> getAllTasks(int projectId, int employeeId);
}
