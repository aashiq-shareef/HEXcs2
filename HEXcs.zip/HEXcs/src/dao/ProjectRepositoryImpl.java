package dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import Entity.model.*;

import util.DBConnection;

public class ProjectRepositoryImpl implements IProjectRepository {
    private Connection connection;
	private PreparedStatement preparedStatement;
	
	public ProjectRepositoryImpl() {
		connection = DBConnection.getConnect();
	}

    public boolean createEmployee(Employee employee) {
        try {
            preparedStatement = connection.prepareStatement("insert into employee values(?,?,?,?,?,?)");
            preparedStatement.setInt(1, employee.getId());
            preparedStatement.setString(2, employee.getName());
            preparedStatement.setString(3, employee.getDesignation());
            preparedStatement.setString(4, employee.getGender());
            preparedStatement.setDouble(5, employee.getSalary());
            preparedStatement.setInt(6, employee.getProject_id());
            int rows = preparedStatement.executeUpdate();
            if (rows > 0) {
                System.out.println("Employee Created Successfully");
            }
            return rows > 0;
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return false;
        }
    }

    public boolean createProject(Project project) {
        try {
            preparedStatement = connection.prepareStatement("insert into project values(?,?,?,?,?)");
            preparedStatement.setInt(1, project.getId());
            preparedStatement.setString(2, project.getProjectName());
            preparedStatement.setString(3, project.getDescription());
            preparedStatement.setString(4, project.getStartDate());
            preparedStatement.setString(5, project.getStatus());

            int rows = preparedStatement.executeUpdate();
            if (rows > 0) {
                System.out.println("Project Created Successfully");
            }
            return rows > 0;
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return false;
        }
    }

    public boolean createTask(Task task) {
        try {
            preparedStatement = connection.prepareStatement("INSERT INTO task (task_id, task_name, project_id, employee_id, status) VALUES (?, ?, ?, ?, ?)");
            preparedStatement.setInt(1, task.getTask_id());
            preparedStatement.setString(2, task.getTask_name());
            preparedStatement.setInt(3, task.getProject_id());
            preparedStatement.setInt(4, task.getEmployee_id());
            preparedStatement.setString(5, task.getStatus());

            int rows = preparedStatement.executeUpdate();
            if (rows > 0) {
                System.out.println("Task Created Successfully");
            }
            return rows > 0;
        } catch (SQLException e) {
            System.out.println(e.getMessage());
            return false;
        }
    }

    public boolean assignProjectToEmployee(int projectId, int employeeId) {
        try {
            preparedStatement = connection.prepareStatement("UPDATE employee SET project_id = ? WHERE id = ?");
            preparedStatement.setInt(1, projectId);
            preparedStatement.setInt(2, employeeId);

            int rows = preparedStatement.executeUpdate();
            if (rows > 0) {
                System.out.println("Project Assigned Successfully to Employee ID: " + employeeId);
            }
            return rows > 0;
        } catch (SQLException e) {
            System.out.println(e.getMessage());
            return false;
        }
    }

    public boolean deleteEmployee(int userId) {
        try {
            preparedStatement = connection.prepareStatement("DELETE FROM Employee WHERE id = ?");
            preparedStatement.setInt(1, userId);

            int rows = preparedStatement.executeUpdate();
            if (rows > 0) {
                System.out.println("Employee with ID " + userId + " deleted successfully.");
            }
            return rows > 0;
        } catch (SQLException e) {
            System.out.println(e.getMessage());
            return false;
        }
    }

    public boolean assignTaskInProjectToEmployee(int taskId, int projectId, int employeeId) {
        try {
            preparedStatement = connection.prepareStatement("UPDATE task SET project_id = ?, employee_id = ? WHERE task_id = ?");
            preparedStatement.setInt(1, projectId);
            preparedStatement.setInt(2, employeeId);
            preparedStatement.setInt(3, taskId);

            int rows = preparedStatement.executeUpdate();
            if (rows > 0) {
                System.out.println("Task with ID " + taskId + " in project " + projectId + " successfully assigned to employee " + employeeId);
            }
            return rows > 0;
        } catch (SQLException e) {
            System.out.println(e.getMessage());
            return false;
        }
    }

    public boolean deleteProject(int projectId) {
        try {
            preparedStatement = connection.prepareStatement("DELETE FROM Project WHERE Id = ?");
            preparedStatement.setInt(1, projectId);

            int rows = preparedStatement.executeUpdate();
            if (rows > 0) {
                System.out.println("Project with ID " + projectId + " deleted successfully.");
                return true;
            } else {
                System.out.println("Project with ID " + projectId + " not found.");
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return false;
    }

    public List<Task> getAllTasks(int project_id, int employee_id) {
        List<Task> tasks = new ArrayList<>();
        try {
            preparedStatement = connection.prepareStatement("SELECT * FROM Task WHERE project_id= ? AND employee_id = ?");
            preparedStatement.setInt(1, project_id);
            preparedStatement.setInt(2, employee_id);
            ResultSet resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                Task task = new Task();
                task.setTask_id(resultSet.getInt("task_id"));
                task.setTask_name(resultSet.getString("task_name"));
                task.setProject_id(resultSet.getInt("project_id"));
                task.setEmployee_id(resultSet.getInt("employee_id"));
                task.setStatus(resultSet.getString("status"));
                tasks.add(task);
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return tasks;
    }
}
