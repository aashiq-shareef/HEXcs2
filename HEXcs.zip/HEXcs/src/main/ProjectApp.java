package main;

import dao.ProjectRepositoryImpl;
import Entity.model.Employee;
import Entity.model.Project;
import Entity.model.Task;

import java.util.List;
import java.util.Scanner;

public class ProjectApp {
    private static Scanner scanner;
    private static ProjectRepositoryImpl projectRepository;

    public static void main(String[] args) {
        projectRepository = new ProjectRepositoryImpl();
        scanner = new Scanner(System.in);
        
        while(true){
            System.out.println("Menu:");
            System.out.println("1. Create Employee");
            System.out.println("2. Create Project");
            System.out.println("3. Create Task");
            System.out.println("4. Assign project to employee ");
            System.out.println("5. Delete Employee ");
            System.out.println("6. Assign task in project to an Employee");
            System.out.println("7. Delete Project");
            System.out.println("8. Get Tasks for Project and Employee");
            System.out.println("9. Exit");
            System.out.println("Enter your Choice : ");
            

            int choice = scanner.nextInt();
            scanner.nextLine(); 

            switch (choice) {
                case 1:
                    createEmployee();
                    break;
                case 2:
                    createProject();
                    break;
                case 3: 
                    createTask();
                    break;
                case 4: 
                    assignProjectToEmployee();
                    break;
                case 5:
                    deleteEmployee();
                    break;
                case 6:
                    assignTaskToEmployee();
                    break;
                case 7:
                    deleteProject();
                    break;
                case 8:
                    getTasks();
                    break;
                case 9:
                    scanner.close();
                    System.exit(0);
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }

        }
    public static void createEmployee() {
        Employee employee = new Employee();
        System.out.println("Enter employee id: ");
        employee.setId(scanner.nextInt());
        scanner.nextLine();

        System.out.println("Enter employee name: ");
        employee.setName(scanner.nextLine());

        System.out.println("Enter employee designation: ");
        employee.setDesignation(scanner.nextLine());

        System.out.println("Enter employee gender (Male/Female): ");
        employee.setGender(scanner.nextLine());

        System.out.println("Enter Employee Salary: ");
        employee.setSalary(scanner.nextDouble());
        scanner.nextLine();

        System.out.println("Enter employee project id: ");
        int projectId = scanner.nextInt();
        scanner.nextLine();

        employee.setProject_id(projectId);
        projectRepository.createEmployee(employee);
    }

    public static void createProject() {
        Project project = new Project();

        System.out.println("Enter project id: ");
        project.setId(scanner.nextInt());
        scanner.nextLine();

        System.out.println("Enter project name: ");
        project.setProjectName(scanner.nextLine());

        System.out.println("Enter project description: ");
        project.setDescription(scanner.nextLine());

        System.out.println("Enter project start date (YYYY-MM-DD): ");
        project.setStartDate(scanner.nextLine());

        System.out.println("Enter project status : ");
        project.setStatus(scanner.nextLine());

        projectRepository.createProject(project);
    }

    public static void createTask() {
        Task task = new Task();

        System.out.println("Enter Task id: ");
        task.setTask_id(scanner.nextInt());
        scanner.nextLine();

        System.out.println("Enter Task name: ");
        task.setTask_name(scanner.nextLine());

        System.out.println("Enter project id (should be present in project table): ");
        task.setProject_id(scanner.nextInt());
        scanner.nextLine();

        System.out.println("Enter Employee ID(should be present in the Employee table): ");
        task.setEmployee_id(scanner.nextInt());
        scanner.nextLine();

        System.out.println("Enter task status : ");
        task.setStatus(scanner.nextLine());

        projectRepository.createTask(task);
    }

    public static void assignProjectToEmployee() {
        System.out.println("Enter employee ID: ");
        int employeeId = scanner.nextInt();
        scanner.nextLine();

        System.out.println("Enter project ID to assign: ");
        int projectId = scanner.nextInt();
        scanner.nextLine();

        projectRepository.assignProjectToEmployee(projectId, employeeId);
    }
    
    public static void deleteEmployee() {
        System.out.println("Enter employee ID: ");
        int employeeId = scanner.nextInt();
        scanner.nextLine();

        projectRepository.deleteEmployee(employeeId);
    }

    public static void assignTaskToEmployee() {
        System.out.println("Enter project id: ");
        int projectId = scanner.nextInt();
        scanner.nextLine();

        System.out.println("Enter Employee ID: ");
        int employeeId = scanner.nextInt();
        scanner.nextLine();

        System.out.println("Enter Task id: ");
        int taskId = scanner.nextInt();
        scanner.nextLine();

        projectRepository.assignTaskInProjectToEmployee(taskId, projectId, employeeId);
    }

    public static void deleteProject() {
        System.out.println("Enter project id: ");
        int projectId = scanner.nextInt();
        scanner.nextLine();

        projectRepository.deleteProject(projectId);
    }

    public static void getTasks() {
        System.out.println("Enter project id: ");
        int projectId = scanner.nextInt();
        scanner.nextLine();

        System.out.println("Enter Employee ID: ");
        int employeeId = scanner.nextInt();
        scanner.nextLine();

        List<Task> tasks = projectRepository.getAllTasks(projectId, employeeId);
        if (tasks.isEmpty()) {
            System.out.println("No tasks found for employee id: " + employeeId + " and project id: " + projectId);
        } else {
            System.out.println("Tasks for Employee ID: " + employeeId + " and Project ID: " + projectId);
            for (Task task : tasks) {
                System.out.println(task);
            }
        }
    }
}
